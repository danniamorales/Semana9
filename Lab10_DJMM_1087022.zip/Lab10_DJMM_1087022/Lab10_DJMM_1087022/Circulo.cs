﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_DJMM_1087022
{
    internal class Circulo
    {
        private double radio;
        public Circulo(double radio)
        {
            this.radio = radio;
        }

        private double ObtenerPerimetro(double radio)
        {
            double perimetro = (2 * radio) * 3.1416;
            Console.WriteLine("Perimetro: ");
            Console.WriteLine(perimetro);

            Console.ReadKey();
            return perimetro;
        }

        private double ObtenerArea(double radio)
        {
            double area = 3.1416* radio * radio;
            Console.WriteLine("Area: ");
            Console.WriteLine(area);

            Console.ReadKey();
            return area;
        }

        private double ObtenerVolumen(double radio)
        {
            double volumen = (4 * 3.1416 * radio * radio * radio) / 3;
            Console.WriteLine("Volumen: ");
            Console.WriteLine(volumen);

            Console.ReadKey();
            return volumen;
        }

        public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
        {
            this.ObtenerPerimetro(unPerimetro);
            this.ObtenerArea(unArea);
            this.ObtenerVolumen(unVolumen);
        }
    }
}
