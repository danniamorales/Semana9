﻿using System.Runtime.CompilerServices;
using Lab10_DJMM_1087022;
double volumen, area, perimetro, radio;

Console.WriteLine("Ingrese el radio del circulo");
radio = Convert.ToDouble(Console.ReadLine());
Circulo objCirculo = new Circulo(radio);

objCirculo.CalcularGeometria(ref radio, ref radio, ref radio);
